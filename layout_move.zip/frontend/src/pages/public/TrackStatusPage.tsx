import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { publicApi } from '@/api/public.api';
import Navbar from '@/components/public/Navbar';
import Footer from '@/components/public/Footer';
import SEOHead from '@/components/shared/SEOHead';
import { 
    Search, Loader2, CheckCircle2, User, 
    ClipboardList, FileCheck, Map, Building2, Sun, Zap, FileSignature, Banknote,
    ChevronRight, ArrowLeft, ShieldCheck, 
    Activity, Fingerprint, Database, Cpu
} from 'lucide-react';
import toast from 'react-hot-toast';

export default function TrackStatusPage() {
    const [searchId, setSearchId] = useState('');
    const [queryId, setQueryId] = useState('');

    const { data: trackingData, isLoading } = useQuery({
        queryKey: ['track-application', queryId],
        queryFn: () => publicApi.trackApplication(queryId),
        enabled: !!queryId,
        retry: false,
    });

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        const cleanId = searchId.trim();
        if (cleanId.length < 4) {
            toast.error('Query too brief for global search');
            return;
        }
        setQueryId(cleanId);
    };

    const steps = useMemo(() => [
        { label: 'Received', desc: 'Query Entry', icon: ClipboardList, color: 'from-blue-400 to-indigo-600' },
        { label: 'Portal Reg', desc: 'MNRE Registered', icon: FileCheck, color: 'from-indigo-400 to-purple-600' },
        { label: 'Site Survey', desc: 'Tech Inspection', icon: Map, color: 'from-purple-400 to-pink-600' },
        { label: 'Financing', desc: 'Bank Clearance', icon: Building2, color: 'from-pink-400 to-rose-600' },
        { label: 'Installation', desc: 'Solar Mounted', icon: Sun, color: 'from-rose-400 to-orange-600' },
        { label: 'Commissioned', desc: 'System Live', icon: Zap, color: 'from-orange-400 to-yellow-600' },
        { label: 'Applied', desc: 'Subsidy Claim', icon: FileSignature, color: 'from-yellow-400 to-amber-600' },
        { label: 'Processing', desc: 'Verification', icon: Loader2, color: 'from-amber-400 to-orange-500' },
        { label: 'Disbursed', desc: 'Payment Paid', icon: Banknote, color: 'from-orange-400 to-emerald-600' }
    ], []);

    const currentStep = trackingData?.data?.step_index || 0;
    const progressPercent = Math.min((currentStep / steps.length) * 100, 100);

    return (
        <div className="min-h-screen bg-[#020617] text-slate-200 selection:bg-accent selection:text-white font-sans overflow-x-hidden">
            <SEOHead title="Solar Dashboard | Track Your Application" />
            <Navbar />

            {/* Immersive Background Particles */}
            <div className="fixed inset-0 pointer-events-none">
                <div className="absolute top-[10%] left-[10%] w-[40vw] h-[40vw] bg-primary/20 rounded-full blur-[150px] animate-pulse" />
                <div className="absolute bottom-[10%] right-[10%] w-[30vw] h-[30vw] bg-accent/10 rounded-full blur-[120px] animation-delay-2000 animate-pulse" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03]" />
                
                {/* Random Floating Glowing Particles */}
                <div className="absolute top-1/4 left-1/3 w-1.5 h-1.5 bg-accent rounded-full blur-[2px] animate-[float_4s_infinite_ease-in-out]" />
                <div className="absolute top-2/3 right-1/4 w-2 h-2 bg-primary rounded-full blur-[3px] animate-[float_6s_infinite_ease-in-out_1s]" />
                <div className="absolute bottom-1/4 left-1/2 w-1 h-1 bg-white rounded-full blur-[1px] animate-[float_5s_infinite_ease-in-out_2s]" />
            </div>

            <main className="relative z-10 py-16 md:py-24 px-4">
                <div className="max-w-6xl mx-auto space-y-20">
                    
                    {/* Ultra Hero Header */}
                    <header className="text-center space-y-8 animate-in fade-in slide-in-from-top-12 duration-1000">
                        <div className="inline-flex items-center gap-3 px-6 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-xl shadow-2xl">
                            <Activity size={14} className="text-accent animate-pulse" />
                            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">Live Energy Tracking v4.0.1</span>
                        </div>
                        
                        <div className="space-y-4">
                            <h1 className="text-6xl md:text-8xl font-display font-black tracking-tighter leading-[0.85] text-white">
                                YOUR SOLAR <br/>
                                <span className="bg-gradient-to-r from-accent via-orange-400 to-yellow-400 bg-clip-text text-transparent italic drop-shadow-2xl">JOURNEY</span>
                            </h1>
                            <p className="max-w-xl mx-auto text-slate-500 font-medium text-lg leading-relaxed md:text-xl">
                                Verify the pulse of your project with the industry's most transparent tracker.
                            </p>
                        </div>
                    </header>

                    {/* Glowing Command Search */}
                    <div className="max-w-2xl mx-auto relative group">
                        <div className="absolute -inset-1 bg-gradient-to-r from-primary/50 to-accent/50 rounded-[3rem] blur-xl opacity-20 group-hover:opacity-40 transition-opacity duration-500" />
                        <div className="relative bg-slate-900/80 backdrop-blur-3xl p-2 md:p-3 rounded-[3.5rem] border border-white/10 shadow-3xl">
                            <form onSubmit={handleSearch} className="flex items-center gap-2">
                                <div className="relative flex-grow">
                                    <div className="absolute left-7 top-1/2 -translate-y-1/2 flex items-center gap-3">
                                        <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                                        <Search className="text-slate-500" size={20} />
                                    </div>
                                    <input
                                        type="text"
                                        placeholder="Mobile or ULID ID"
                                        className="w-full pl-16 pr-8 py-6 md:py-7 rounded-[3rem] border-0 bg-transparent focus:ring-0 text-xl font-bold text-white placeholder:text-slate-600"
                                        value={searchId}
                                        onChange={(e) => setSearchId(e.target.value)}
                                    />
                                </div>
                                <button
                                    type="submit"
                                    disabled={isLoading}
                                    className="bg-primary hover:bg-accent text-white px-10 py-6 md:py-7 rounded-[3rem] font-black uppercase tracking-widest text-xs transition-all active:scale-95 shadow-xl shadow-primary/20 flex items-center gap-3 group/btn"
                                >
                                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'INITIATE TRACKING'}
                                    <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
                                </button>
                            </form>
                        </div>
                    </div>

                    {/* Result Interface */}
                    {queryId && !isLoading && trackingData?.success && (
                        <div className="animate-in fade-in slide-in-from-bottom-20 duration-1000 ease-out space-y-20">
                            
                            {/* Energy Path Timeline: NOW AT THE TOP */}
                            <div className="bg-slate-900/60 backdrop-blur-3xl rounded-[4rem] p-12 md:p-20 border border-white/5 relative group/timeline">
                                <div className="text-center mb-20 space-y-2">
                                    <div className="text-[10px] font-black text-accent uppercase tracking-[0.4em]">Energy Execution Path</div>
                                    <h3 className="text-3xl md:text-5xl font-display font-black text-white tracking-tighter">PROJECT MILESTONES</h3>
                                </div>

                                <div className="relative">
                                    {/* Animated Energy Beam Connector */}
                                    <div className="absolute top-10 left-[5%] right-[5%] h-1 bg-white/5 rounded-full overflow-hidden hidden lg:block">
                                        <div 
                                            className="h-full bg-gradient-to-r from-accent via-yellow-400 to-accent transition-all duration-2000 ease-in-out shadow-[0_0_15px_rgba(255,149,0,0.4)]" 
                                            style={{ 
                                                width: `${Math.min(((currentStep - 1) / (steps.length - 1)) * 90, 90)}%`,
                                                backgroundSize: '200% 100%',
                                                animation: 'energyBeam 2s linear infinite'
                                            }}
                                        />
                                    </div>

                                    {/* Milestone Points */}
                                    <div className="grid grid-cols-2 lg:grid-cols-9 gap-10 md:gap-16 lg:gap-4 lg:px-6 relative">
                                        {steps.map((step, idx) => {
                                            const stepNum = idx + 1;
                                            const isCompleted = currentStep > stepNum;
                                            const isActive = currentStep === stepNum;
                                            const StepIcon = step.icon;

                                            return (
                                                <div key={idx} className="flex flex-col items-center group/step transition-all duration-500">
                                                    <div className={`relative w-20 h-20 md:w-24 md:h-24 rounded-[2rem] flex items-center justify-center border-2 transition-all duration-700 shadow-2xl ${
                                                        isCompleted ? 'bg-gradient-to-br from-accent to-orange-600 border-white/10 text-white scale-90' : 
                                                        isActive ? 'bg-white border-white text-dark scale-125 z-20 shadow-[0_0_40px_rgba(255,149,0,0.3)]' : 
                                                        'bg-white/5 border-white/10 text-slate-700'
                                                    }`}>
                                                        {isCompleted ? <CheckCircle2 size={32} /> : (
                                                            <StepIcon size={28} className={isActive ? 'animate-pulse' : ''} />
                                                        )}
                                                        {isActive && <div className="absolute -inset-1 rounded-[2.2rem] bg-accent/20 animate-ping -z-10" />}
                                                    </div>
                                                    <div className="mt-8 text-center space-y-1">
                                                        <div className={`text-[10px] font-black uppercase tracking-[0.15em] leading-tight ${isActive ? 'text-white' : 'text-slate-600'}`}>
                                                            {step.label}
                                                        </div>
                                                        <div className={`text-[8px] font-bold uppercase tracking-[0.2em] ${isActive ? 'text-accent' : 'text-slate-800'} whitespace-normal max-w-[80px] mx-auto`}>
                                                            {step.desc}
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>

                            {/* Dashboard Grid Card */}
                            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
                                
                                {/* Status Orb Card */}
                                <div className="lg:col-span-8 bg-slate-900/40 backdrop-blur-2xl rounded-[4rem] p-12 md:p-16 border border-white/5 shadow-2xl relative overflow-hidden group">
                                    <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 blur-3xl -z-10 rounded-full group-hover:scale-150 transition-transform duration-1000" />
                                    
                                    <div className="flex flex-col md:flex-row items-center gap-16">
                                        {/* Solar Core Gauge */}
                                        <div className="relative shrink-0 flex items-center justify-center">
                                            {/* Outer Ring */}
                                            <svg className="w-56 h-56 -rotate-90">
                                                <circle cx="112" cy="112" r="104" stroke="currentColor" strokeWidth="2" fill="transparent" className="text-white/5" />
                                                <circle 
                                                    cx="112" cy="112" r="104" stroke="currentColor" strokeWidth="8" fill="transparent" 
                                                    className="text-accent drop-shadow-[0_0_8px_rgba(255,149,0,0.5)] transition-all duration-1000 ease-out"
                                                    strokeDasharray={2 * Math.PI * 104}
                                                    strokeDashoffset={2 * Math.PI * 104 * (1 - progressPercent/100)}
                                                    strokeLinecap="round"
                                                />
                                            </svg>
                                            {/* Core Icon */}
                                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                                                <div className="w-28 h-28 rounded-full bg-gradient-to-br from-slate-800 to-black flex items-center justify-center shadow-inner-lg mb-2 relative group-hover:scale-110 transition-transform">
                                                    {(() => {
                                                        const StepIcon = steps[currentStep - 1]?.icon || ClipboardList;
                                                        return <StepIcon size={48} className="text-white animate-[solarGlow_4s_infinite]" />;
                                                    })()}
                                                </div>
                                                <div className="text-accent font-black text-2xl tracking-tighter">{Math.round(progressPercent)}%</div>
                                                <div className="text-[8px] font-black uppercase text-slate-500 tracking-[0.2em]">Milestone Completion</div>
                                            </div>
                                        </div>

                                        <div className="flex-grow space-y-8 text-center md:text-left">
                                            <div>
                                                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-accent/10 border border-accent/20 text-accent text-[9px] font-black uppercase tracking-widest mb-4">
                                                    Verification Stage Completed
                                                </div>
                                                <h2 className="text-5xl md:text-7xl font-display font-black text-white leading-none tracking-tighter">
                                                    {trackingData.data.status}
                                                </h2>
                                            </div>
                                            <div className="space-y-4">
                                                <p className="text-xl text-slate-400 font-medium leading-relaxed max-w-lg">
                                                    {trackingData.data.meaning}
                                                </p>
                                                <div className="flex flex-col md:flex-row items-center gap-6 pt-8 border-t border-white/5">
                                                    <div className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-xl border border-white/5">
                                                        <Fingerprint size={16} className="text-accent" />
                                                        <span className="text-xs font-bold text-slate-300">ID: {trackingData.data.reference}</span>
                                                    </div>
                                                    <div className="text-[10px] font-black uppercase text-slate-600 tracking-widest">
                                                        Synchronized {new Date(trackingData.data.updated_at).toLocaleDateString()}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Verified Data Stream Column */}
                                <div className="lg:col-span-4 grid grid-rows-2 gap-8">
                                    <div className="bg-slate-900/40 backdrop-blur-xl rounded-[3.5rem] p-10 border border-white/5 flex flex-col items-center text-center space-y-6 relative overflow-hidden group">
                                        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 blur-3xl -z-10 rounded-full" />
                                        <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center text-accent border border-white/10 shadow-xl group-hover:rotate-12 transition-transform">
                                            <User size={32} />
                                        </div>
                                        <div>
                                            <div className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-2">Verified Beneficiary</div>
                                            <div className="text-2xl font-display font-black text-white truncate max-w-[200px]">{trackingData.data.beneficiary}</div>
                                        </div>
                                        <div className="w-full h-px bg-white/5" />
                                        <div className="flex items-center gap-6 justify-center w-full">
                                            <div>
                                                <div className="text-[8px] font-black uppercase text-slate-500 tracking-widest mb-1">State Level</div>
                                                <div className="font-bold text-sm text-slate-100">{trackingData.data.district}</div>
                                            </div>
                                            <div className="w-px h-8 bg-white/5" />
                                            <div>
                                                <div className="text-[8px] font-black uppercase text-slate-500 tracking-widest mb-1">Grid Area</div>
                                                <div className="font-bold text-sm text-slate-100">Zone-A</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="bg-gradient-to-br from-primary to-indigo-900 rounded-[3.5rem] p-10 text-white relative overflow-hidden group">
                                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 blur-[60px] rounded-full" />
                                        <div className="relative z-10 flex flex-col h-full justify-between">
                                            <div className="space-y-4">
                                                <div className="flex items-center gap-2">
                                                    <Cpu size={18} className="text-accent" />
                                                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">Next Protocol</span>
                                                </div>
                                                <h4 className="text-2xl font-display font-black tracking-tight leading-tight">
                                                    {trackingData.data.next_step}
                                                </h4>
                                            </div>
                                            <button className="w-full mt-6 px-6 py-4 bg-white/10 hover:bg-white/20 border border-white/10 rounded-2xl font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2">
                                                <Database size={14} /> Open Tech Center
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Enhanced Error Screen */}
                    {queryId && !isLoading && !trackingData?.success && (
                        <div className="bg-slate-900/40 backdrop-blur-3xl rounded-[5rem] p-16 md:p-32 text-center border border-white/5 animate-in zoom-in-95 duration-700 relative overflow-hidden group">
                            <div className="absolute top-0 left-0 w-96 h-96 bg-red-500/5 blur-[120px] -z-10 rounded-full -ml-40 -mt-40 transition-transform duration-1000 group-hover:scale-125" />
                            <div className="w-28 h-28 bg-white/5 rounded-[3rem] flex items-center justify-center mx-auto mb-10 border border-white/10 shadow-inner shadow-red-500/10 text-red-500/80">
                                <Activity className="w-14 h-14" />
                            </div>
                            <h2 className="text-5xl md:text-7xl font-display font-black text-white mb-6 tracking-tighter leading-none">ID NOT <br/>RECOGNIZED</h2>
                            <p className="text-slate-500 text-lg md:text-2xl max-w-xl mx-auto mb-16 leading-relaxed font-medium">
                                The tracking protocol <span className="text-white font-black">"{queryId}"</span> has not been initialized in our verification database.
                            </p>
                            <div className="flex flex-col md:flex-row items-center justify-center gap-6">
                                <button
                                    onClick={() => { setSearchId(''); setQueryId(''); }}
                                    className="w-full md:w-auto bg-white text-dark px-14 py-7 rounded-[2.5rem] font-black text-sm uppercase tracking-widest hover:bg-accent hover:text-white transition-all shadow-2xl flex items-center justify-center gap-4"
                                >
                                    <ArrowLeft size={18} />
                                    RE-INITIALIZE
                                </button>
                                <a href="/contact" className="px-10 py-7 font-black text-xs uppercase tracking-widest text-slate-500 hover:text-white transition-all">
                                    Contact Grid Control
                                </a>
                            </div>
                        </div>
                    )}

                    {/* Initial Technical Guidelines */}
                    {!queryId && !isLoading && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 justify-items-center animate-in fade-in duration-1000 delay-500">
                            {[
                                { icon: <Database className="text-accent" />, title: 'Real-time Sync', text: 'Live API bridge to pmsuryaghar.gov.in portal.' },
                                { icon: <ShieldCheck className="text-primary" />, title: 'Secure Access', text: 'End-to-end encrypted tracking identifiers.' },
                                { icon: <Zap className="text-yellow-400" />, title: 'Energy Node', text: 'Tracking activates within 15 mins of node entry.' }
                            ].map((item, i) => (
                                <div key={i} className="group relative w-full h-full">
                                    <div className="absolute inset-0 bg-white/5 rounded-[3.5rem] blur-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
                                    <div className="relative h-full bg-slate-900/60 backdrop-blur-xl p-10 md:p-12 rounded-[3.5rem] border border-white/5 flex flex-col items-center text-center space-y-8 transform hover:translate-y-[-10px] transition-all duration-500">
                                        <div className="w-20 h-20 bg-white/5 rounded-3xl shadow-2xl flex items-center justify-center border border-white/10 group-hover:rotate-12 transition-transform">
                                            {item.icon}
                                        </div>
                                        <div className="space-y-4">
                                            <h4 className="text-2xl font-display font-black text-white tracking-tight">{item.title}</h4>
                                            <p className="text-slate-500 text-sm font-medium leading-relaxed uppercase tracking-wider">
                                                {item.text}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </main>

            <Footer />
        </div>
    );
}
