import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { publicApi } from '@/api/public.api';
import Navbar from '@/components/public/Navbar';
import Footer from '@/components/public/Footer';
import SEOHead from '@/components/shared/SEOHead';
import { 
    Search, Loader2, CheckCircle2, Clock, User, 
    ClipboardList, FileCheck, Map, Building2, Sun, Zap, FileSignature, Banknote,
    ChevronRight, ArrowRight, ArrowLeft, ShieldCheck, HelpCircle
} from 'lucide-react';
import toast from 'react-hot-toast';

export default function TrackStatusPage() {
    const [searchId, setSearchId] = useState('');
    const [queryId, setQueryId] = useState('');

    const { data: trackingData, isLoading } = useQuery({
        queryKey: ['track-application', queryId],
        queryFn: () => publicApi.trackApplication(queryId),
        enabled: !!queryId,
        retry: false,
    });

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        const cleanId = searchId.trim();
        if (cleanId.length < 4) {
            toast.error('Search query is too short');
            return;
        }
        setQueryId(cleanId);
    };

    const steps = useMemo(() => [
        { label: 'Received', desc: 'Query Entry', icon: ClipboardList },
        { label: 'Portal Reg', desc: 'MNRE Registered', icon: FileCheck },
        { label: 'Site Survey', desc: 'Tech Inspection', icon: Map },
        { label: 'Financing', desc: 'Bank Clearance', icon: Building2 },
        { label: 'Installation', desc: 'Solar Mounted', icon: Sun },
        { label: 'Commissioned', desc: 'System Live', icon: Zap },
        { label: 'Applied', desc: 'Subsidy Claim', icon: FileSignature },
        { label: 'Processing', desc: 'Verification', icon: Loader2 },
        { label: 'Disbursed', desc: 'Payment Paid', icon: Banknote }
    ], []);

    const currentStep = trackingData?.data?.step_index || 0;

    return (
        <div className="min-h-screen bg-[#FDFEFE] flex flex-col font-sans selection:bg-accent selection:text-white">
            <SEOHead title="Track Your Application | PM Surya Ghar - Suryamitra" />
            <Navbar />

            {/* Mesh Background */}
            <div className="fixed inset-0 -z-10 pointer-events-none opacity-40">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/10 rounded-full blur-[120px]" />
                <div className="absolute top-[30%] right-[-5%] w-[35%] h-[35%] bg-accent/10 rounded-full blur-[120px]" />
                <div className="absolute bottom-[0%] left-[20%] w-[30%] h-[30%] bg-indigo-100 rounded-full blur-[100px]" />
            </div>

            <main className="flex-grow py-12 md:py-20 lg:py-24 px-4 overflow-x-hidden">
                <div className="max-w-6xl mx-auto space-y-16">
                    
                    {/* Centered Hero Header */}
                    <header className="text-center max-w-2xl mx-auto space-y-6 animate-in fade-in slide-in-from-top-4 duration-1000">
                        <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-full bg-white shadow-premium border border-slate-100 mb-2">
                            <span className="relative flex h-3 w-3">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-3 w-3 bg-accent"></span>
                            </span>
                            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Global Tracking Enabled</span>
                        </div>
                        <h1 className="text-5xl md:text-7xl font-display font-black text-slate-900 tracking-tight leading-[0.95] md:leading-[1.1]">
                            Track Your Solar <br className="hidden md:block"/>
                            <span className="text-accent italic relative">
                                Application
                                <svg className="absolute -bottom-2 left-0 w-full h-3 text-accent/20" viewBox="0 0 100 10" preserveAspectRatio="none">
                                    <path d="M0 5 Q 50 0, 100 5 Q 50 10, 0 5" fill="currentColor" />
                                </svg>
                            </span>
                        </h1>
                        <p className="text-slate-500 text-lg md:text-xl font-medium leading-relaxed">
                            Check the real-time status of your PM Surya Ghar journey using your Mobile Number or Reference ID.
                        </p>
                    </header>

                    {/* Centered Search Command */}
                    <div className="max-w-3xl mx-auto transform hover:translate-y-[-4px] transition-all duration-500">
                        <div className="bg-white p-3 md:p-4 rounded-[3.5rem] shadow-2xl shadow-slate-200/50 border border-slate-100/50 backdrop-blur-3xl">
                            <form onSubmit={handleSearch} className="flex flex-col md:flex-row items-center gap-3">
                                <div className="relative flex-grow w-full group">
                                    <Search className="absolute left-7 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-accent transition-all duration-300" size={24} />
                                    <input
                                        type="text"
                                        placeholder="Enter Mobile (e.g. 98...) or Ref ID"
                                        className="w-full pl-16 pr-8 py-7 md:py-8 rounded-[3rem] border-0 bg-slate-50 focus:bg-white focus:ring-[12px] focus:ring-accent/5 transition-all text-xl md:text-2xl font-black text-slate-900 placeholder:text-slate-300 placeholder:font-bold"
                                        value={searchId}
                                        onChange={(e) => setSearchId(e.target.value)}
                                    />
                                </div>
                                <button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full md:w-auto bg-dark text-white hover:bg-primary px-14 py-7 md:py-8 rounded-[3rem] font-black text-lg transition-all active:scale-95 shadow-2xl shadow-dark/20 flex items-center justify-center gap-4 group overflow-hidden relative"
                                >
                                    {isLoading ? (
                                        <Loader2 className="w-7 h-7 animate-spin text-accent" />
                                    ) : (
                                        <>
                                            <span className="relative z-10 uppercase tracking-widest">Track Now</span>
                                            <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center group-hover:translate-x-2 transition-transform relative z-10">
                                                <ArrowRight size={20} />
                                            </div>
                                        </>
                                    )}
                                </button>
                            </form>
                        </div>
                    </div>

                    {/* Results Container */}
                    {queryId && !isLoading && trackingData?.success && (
                        <div className="space-y-12 max-w-6xl mx-auto">
                            
                            {/* Iconic Results Card */}
                            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in slide-in-from-bottom-12 duration-1000 ease-out">
                                
                                {/* Left Side: Status Hero */}
                                <div className="lg:col-span-8 bg-white rounded-[4rem] p-10 md:p-16 shadow-2xl shadow-slate-200/60 border border-slate-50 relative overflow-hidden group">
                                    <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-br from-primary/10 to-transparent blur-[80px] -z-10 rounded-full transition-transform duration-1000 group-hover:scale-125" />
                                    
                                    <div className="flex flex-col md:flex-row items-center gap-10">
                                        {/* Status Circle */}
                                        <div className="relative shrink-0">
                                            <div className="w-40 h-40 md:w-48 md:h-48 rounded-[3.5rem] bg-gradient-to-br from-slate-900 to-primary flex items-center justify-center text-white shadow-premium relative z-10">
                                                {(() => {
                                                    const StepIcon = steps[currentStep - 1]?.icon || ClipboardList;
                                                    return <StepIcon size={64} className="animate-pulse-subtle" />;
                                                })()}
                                            </div>
                                            <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full scale-75 animate-pulse" />
                                        </div>

                                        <div className="flex-grow text-center md:text-left space-y-6">
                                            <div>
                                                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 text-accent text-[9px] font-black uppercase tracking-widest mb-3">
                                                    Current Status Level
                                                </div>
                                                <h2 className="text-4xl md:text-6xl font-display font-black text-slate-900 leading-none">
                                                    {trackingData.data.status}
                                                </h2>
                                            </div>
                                            <div className="flex flex-col md:flex-row items-center gap-6 justify-between pt-6 border-t border-slate-100">
                                                <div className="space-y-4 max-w-md">
                                                    <p className="text-lg text-slate-500 font-medium leading-relaxed">
                                                        {trackingData.data.meaning}
                                                    </p>
                                                    <div className="flex items-center justify-center md:justify-start gap-4">
                                                        <div className="flex items-center gap-2 bg-slate-50 px-4 py-2 rounded-2xl border border-slate-100 shadow-sm">
                                                            <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" />
                                                            <span className="text-xs font-bold text-slate-900">{trackingData.data.reference}</span>
                                                        </div>
                                                        <div className="text-xs font-bold text-slate-400">Updated {new Date(trackingData.data.updated_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric'})}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Action Banner */}
                                    <div className="mt-12 bg-[#0A111F] rounded-[2.5rem] p-8 md:p-10 flex flex-col md:flex-row items-center gap-8 relative overflow-hidden group/action">
                                        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 blur-3xl rounded-full translate-x-16 -translate-y-16" />
                                        <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center text-accent shrink-0 border border-white/10 group-hover/action:rotate-12 transition-transform">
                                            <Clock size={32} />
                                        </div>
                                        <div className="text-center md:text-left flex-grow space-y-1">
                                            <div className="text-[10px] font-black uppercase tracking-[0.2em] text-accent/80">Next Professional Action</div>
                                            <h4 className="text-xl md:text-2xl font-bold text-white leading-tight">
                                                {trackingData.data.next_step}
                                            </h4>
                                        </div>
                                        <button className="w-full md:w-auto px-8 py-4 bg-white text-dark rounded-2xl font-black text-sm hover:bg-accent hover:text-white transition-all shadow-xl shadow-dark/20 flex items-center justify-center gap-2">
                                            <HelpCircle size={18} />
                                            Help Center
                                        </button>
                                    </div>
                                </div>

                                {/* Right Side: Detals Column */}
                                <div className="lg:col-span-4 space-y-8">
                                    <div className="bg-white rounded-[3rem] p-10 shadow-xl border border-slate-50 flex flex-col items-center text-center space-y-6">
                                        <div className="w-20 h-20 bg-slate-50 rounded-[2rem] flex items-center justify-center text-slate-900 border border-slate-100 shadow-sm">
                                            <User size={36} />
                                        </div>
                                        <div>
                                            <div className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-1">Beneficiary Name</div>
                                            <div className="text-2xl font-display font-black text-slate-900 truncate max-w-[200px]">{trackingData.data.beneficiary}</div>
                                        </div>
                                        <div className="w-full h-px bg-slate-50" />
                                        <div className="grid grid-cols-2 gap-4 w-full">
                                            <div className="bg-slate-50 p-4 rounded-3xl border border-slate-100">
                                                <div className="text-[8px] font-black uppercase tracking-[0.2em] text-slate-400 mb-1">State Level</div>
                                                <div className="font-bold text-sm text-slate-700">{trackingData.data.district}</div>
                                            </div>
                                            <div className="bg-slate-50 p-4 rounded-3xl border border-slate-100">
                                                <div className="text-[8px] font-black uppercase tracking-[0.2em] text-slate-400 mb-1">System Verification</div>
                                                <div className="font-bold text-sm text-slate-700 flex items-center justify-center gap-1.5"><ShieldCheck size={12} className="text-green-500" /> Secure</div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Quick Guide Card */}
                                    <div className="bg-gradient-to-br from-primary to-primary-dark rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden group">
                                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 blur-[60px] rounded-full" />
                                        <h4 className="text-2xl font-display font-black mb-4">Did You Know?</h4>
                                        <p className="text-white/70 text-sm leading-relaxed mb-6">
                                            Suryamitra handles the entire portal registration and technical survey within 48 hours of document receipt.
                                        </p>
                                        <button className="text-xs font-black uppercase tracking-widest flex items-center gap-2 group-hover:gap-4 transition-all">
                                            Read More History <ChevronRight size={14} />
                                        </button>
                                    </div>
                                </div>
                            </div>

                            {/* Milestone Timeline: Full Width */}
                            <div className="bg-white rounded-[4rem] p-12 md:p-20 shadow-premium border border-slate-50 overflow-hidden relative group/timeline">
                                <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-slate-50/50 to-transparent -z-10" />
                                <div className="text-center mb-16">
                                    <div className="text-sm font-black text-primary uppercase tracking-[0.4em] mb-2">Project Execution Map</div>
                                    <h3 className="text-3xl md:text-4xl font-display font-black text-slate-900">Live Journey Tracking</h3>
                                </div>

                                {/* Custom Large Pipeline */}
                                <div className="relative pt-12 pb-8">
                                    {/* Desktop Timeline */}
                                    <div className="hidden lg:flex justify-between items-start relative px-4">
                                        {/* Connector Backing */}
                                        <div className="absolute top-[32px] left-[5%] right-[5%] h-1 bg-slate-100 -z-0 rounded-full" />
                                        {/* Dynamic Progress Fill */}
                                        <div 
                                            className="absolute top-[32px] left-[5%] h-1 bg-gradient-to-r from-primary via-accent to-accent-dark transition-all duration-1500 ease-in-out z-10 rounded-full" 
                                            style={{ width: `${Math.min(((currentStep - 1) / (steps.length - 1)) * 90, 90)}%` }}
                                        />

                                        {steps.map((step, idx) => {
                                            const stepNum = idx + 1;
                                            const isCompleted = currentStep > stepNum;
                                            const isActive = currentStep === stepNum;
                                            const StepIcon = step.icon;

                                            return (
                                                <div key={idx} className="flex flex-col items-center group/step relative z-20 w-[11%]">
                                                    <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center border-4 transition-all duration-700 shadow-xl ${
                                                        isCompleted ? 'bg-primary border-white text-white rotate-[15deg]' : 
                                                        isActive ? 'bg-white border-accent text-accent scale-125 -translate-y-2 shadow-2xl shadow-accent/20 z-30' : 
                                                        'bg-white border-slate-50 text-slate-200'
                                                    }`}>
                                                        {isCompleted ? <CheckCircle2 size={28} /> : (
                                                            <StepIcon size={24} className={isActive ? 'animate-bounce-subtle' : ''} />
                                                        )}
                                                    </div>
                                                    <div className="mt-8 text-center space-y-1">
                                                        <div className={`text-[10px] font-black uppercase tracking-[0.15em] leading-tight ${isActive ? 'text-slate-900' : 'text-slate-400'}`}>
                                                            {step.label}
                                                        </div>
                                                        <div className={`text-[9px] font-bold uppercase tracking-widest ${isActive ? 'text-accent' : 'text-slate-200'} whitespace-nowrap`}>
                                                            {step.desc}
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>

                                    {/* Tablet/Mobile Horizontal Scrollable Timeline */}
                                    <div className="lg:hidden">
                                        <div className="flex overflow-x-auto pb-12 pt-4 px-4 gap-12 no-scrollbar snap-x">
                                            {steps.map((step, idx) => {
                                                const stepNum = idx + 1;
                                                const isCompleted = currentStep > stepNum;
                                                const isActive = currentStep === stepNum;
                                                const StepIcon = step.icon;

                                                return (
                                                    <div key={idx} className="flex flex-col items-center shrink-0 w-24 snap-center">
                                                        <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center border-4 transition-all ${
                                                            isCompleted ? 'bg-primary border-white text-white' : 
                                                            isActive ? 'bg-white border-accent text-accent scale-110 shadow-lg' : 
                                                            'bg-white border-slate-50 text-slate-200'
                                                        }`}>
                                                            {isCompleted ? <CheckCircle2 size={24} /> : <StepIcon size={24} />}
                                                        </div>
                                                        <div className="mt-4 text-center">
                                                            <div className={`text-[9px] font-black uppercase tracking-widest ${isActive ? 'text-slate-900' : 'text-slate-400'}`}>{step.label}</div>
                                                            <div className="text-[8px] text-slate-300 font-bold uppercase mt-1">{step.desc}</div>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Not Found Screen */}
                    {queryId && !isLoading && !trackingData?.success && (
                        <div className="bg-white rounded-[4rem] p-16 md:p-24 text-center shadow-premium border border-slate-50 animate-in zoom-in-95 duration-700 relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-64 h-64 bg-red-50/50 blur-3xl -z-10 rounded-full -ml-32 -mt-32" />
                            <div className="w-24 h-24 bg-red-50 rounded-[2rem] flex items-center justify-center mx-auto mb-10 border border-red-100 shadow-sm text-red-500">
                                <Search className="w-12 h-12" />
                            </div>
                            <h2 className="text-4xl md:text-5xl font-display font-black text-slate-900 mb-4">Application Missing</h2>
                            <p className="text-slate-500 text-lg md:text-xl max-w-md mx-auto mb-12 leading-relaxed">
                                We couldn't locate any application matching <span className="text-slate-900 font-black">"{queryId}"</span>. Please confirm your details or contact helpdesk.
                            </p>
                            <div className="flex flex-col md:flex-row items-center justify-center gap-4">
                                <button
                                    onClick={() => { setSearchId(''); setQueryId(''); }}
                                    className="bg-slate-900 text-white px-12 py-6 rounded-[2rem] font-black text-lg hover:bg-primary transition-all shadow-xl shadow-dark/20 flex items-center gap-3"
                                >
                                    <ArrowLeft size={20} />
                                    Search Again
                                </button>
                                <a href="/contact" className="px-12 py-6 rounded-[2rem] font-black text-lg text-slate-500 hover:text-primary transition-all">
                                    Contact Support
                                </a>
                            </div>
                        </div>
                    )}

                    {/* Global Guidelines */}
                    {!queryId && !isLoading && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 justify-items-center animate-in fade-in duration-1000 delay-300">
                            {[
                                { icon: <ClipboardList className="text-primary" />, title: 'Entry Point', text: 'Tracking activates 30 mins after submission.' },
                                { icon: <ShieldCheck className="text-accent" />, title: 'Verification', iconBg: 'bg-accent/10', color: 'text-accent' },
                                { icon: <Zap className="text-emerald-500" />, title: 'Real-time Status', text: 'Live API sync directly from Discom portal.' }
                            ].map((item, i) => (
                                <div key={i} className="group relative max-w-sm">
                                    <div className="absolute inset-0 bg-primary/5 rounded-[3rem] blur-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
                                    <div className="relative bg-white/40 p-10 rounded-[3rem] border border-white shadow-premium flex flex-col items-center text-center space-y-6 transform hover:translate-y-[-8px] transition-all">
                                        <div className="w-16 h-16 bg-white rounded-2xl shadow-premium flex items-center justify-center">
                                            {item.icon}
                                        </div>
                                        <div>
                                            <h4 className="text-xl font-display font-black text-slate-900 mb-2">{item.title}</h4>
                                            <p className="text-slate-500 text-sm font-medium leading-relaxed">
                                                {item.text || 'Secure tracking using military-grade ULID identifiers.'}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </main>

            <Footer />
        </div>
    );
}
