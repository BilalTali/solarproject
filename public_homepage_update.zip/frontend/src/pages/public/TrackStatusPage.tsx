import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { publicApi } from '@/api/public.api';
import Navbar from '@/components/public/Navbar';
import Footer from '@/components/public/Footer';
import SEOHead from '@/components/shared/SEOHead';
import { Search, Loader2, CheckCircle2, Clock, MapPin, Calendar, User } from 'lucide-react';
import toast from 'react-hot-toast';

export default function TrackStatusPage() {
    const [searchId, setSearchId] = useState('');
    const [queryId, setQueryId] = useState('');

    const { data: trackingData, isLoading } = useQuery({
        queryKey: ['track-application', queryId],
        queryFn: () => publicApi.trackApplication(queryId),
        enabled: !!queryId,
        retry: false,
    });

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        if (searchId.trim().length < 4) {
            toast.error('Please enter at least 4 characters');
            return;
        }
        setQueryId(searchId.trim());
    };

    const steps = [
        { label: 'Received', desc: 'Query received' },
        { label: 'Registered', desc: 'Portal registration' },
        { label: 'Survey', desc: 'Site inspection' },
        { label: 'Financing', desc: 'Bank processing' },
        { label: 'Installation', desc: 'Solar installed' },
        { label: 'Commissioned', desc: 'System tested' },
        { label: 'Claim Filed', desc: 'Subsidy request' },
        { label: 'Processing', desc: 'Subsidy applied' },
        { label: 'Disbursed', desc: 'Subsidy paid' }
    ];

    const currentStep = trackingData?.data?.step_index || 0;

    return (
        <div className="min-h-screen bg-[#f8fafc] flex flex-col font-sans">
            <SEOHead title="Track Your Solar Application | PM Surya Ghar" />
            <Navbar />

            <main className="flex-grow flex flex-col items-center justify-center py-12 px-4 relative overflow-hidden">
                {/* Decorative Elements */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-gradient-to-b from-primary/5 to-transparent blur-3xl -z-10 rounded-full" />
                
                <div className="w-full max-w-4xl mx-auto">
                    {/* Hero Header */}
                    <div className="text-center mb-16 space-y-4">
                        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-xs font-black uppercase tracking-widest animate-fade-in">
                            <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                            </span>
                            Live Tracking System
                        </div>
                        <h1 className="text-5xl md:text-6xl font-display font-black text-slate-900 tracking-tight leading-none">
                            Track Your <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent italic">Application</span>
                        </h1>
                        <p className="text-slate-500 text-lg max-w-xl mx-auto font-medium">
                            Transparency at every step. Real-time updates on your journey to energy independence.
                        </p>
                    </div>

                    {/* Premium Search Card */}
                    <div className="bg-white rounded-[3rem] p-4 shadow-2xl shadow-primary/10 border border-white/20 backdrop-blur-xl mb-12 transform hover:scale-[1.01] transition-all duration-500">
                        <form onSubmit={handleSearch} className="relative flex flex-col md:flex-row items-center gap-2">
                            <div className="relative flex-grow w-full">
                                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-primary transition-colors" size={24} />
                                <input
                                    type="text"
                                    placeholder="Enter Mobile Number or Reference ID"
                                    className="w-full pl-16 pr-6 py-6 rounded-[2.5rem] border-0 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-primary/5 transition-all text-xl font-bold text-slate-800 placeholder:text-slate-300"
                                    value={searchId}
                                    onChange={(e) => setSearchId(e.target.value)}
                                />
                            </div>
                            <button
                                type="submit"
                                disabled={isLoading}
                                className="w-full md:w-auto bg-dark text-white hover:bg-primary px-12 py-6 rounded-[2.5rem] font-black text-lg transition-all active:scale-95 shadow-lg shadow-dark/20 flex items-center justify-center gap-3 group"
                            >
                                {isLoading ? (
                                    <Loader2 className="w-6 h-6 animate-spin" />
                                ) : (
                                    <>
                                        Track Progress
                                        <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center group-hover:translate-x-1 transition-transform">
                                            <Search size={14} />
                                        </div>
                                    </>
                                )}
                            </button>
                        </form>
                    </div>

                    {/* Results Context */}
                    {queryId && !isLoading && trackingData?.success && (
                        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
                            {/* Stats Overview */}
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-4">
                                    <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                                        <User size={24} />
                                    </div>
                                    <div>
                                        <div className="text-[10px] font-black uppercase tracking-widest text-slate-400">Beneficiary</div>
                                        <div className="font-bold text-slate-900">{trackingData.data.beneficiary}</div>
                                    </div>
                                </div>
                                <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-4">
                                    <div className="w-12 h-12 bg-accent/10 rounded-2xl flex items-center justify-center text-accent">
                                        <MapPin size={24} />
                                    </div>
                                    <div>
                                        <div className="text-[10px] font-black uppercase tracking-widest text-slate-400">Location</div>
                                        <div className="font-bold text-slate-900">{trackingData.data.district}</div>
                                    </div>
                                </div>
                                <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-4">
                                    <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-500">
                                        <Calendar size={24} />
                                    </div>
                                    <div>
                                        <div className="text-[10px] font-black uppercase tracking-widest text-slate-400">Last Update</div>
                                        <div className="font-bold text-slate-900">{new Date(trackingData.data.updated_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</div>
                                    </div>
                                </div>
                            </div>

                            {/* Main Tracking Dashboard */}
                            <div className="bg-white rounded-[3rem] p-8 md:p-16 shadow-2xl shadow-primary/5 border border-slate-100 relative overflow-hidden">
                                <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 blur-3xl -z-10 rounded-full -mr-32 -mt-32" />
                                
                                {/* Status Header */}
                                <div className="flex flex-col md:flex-row items-center justify-between gap-8 mb-16">
                                    <div className="text-center md:text-left">
                                        <div className="text-sm font-black text-primary uppercase tracking-[0.3em] mb-2">Current Status</div>
                                        <h2 className="text-4xl font-display font-black text-slate-900">{trackingData.data.status}</h2>
                                    </div>
                                    <div className="h-20 w-[2px] bg-slate-100 hidden md:block" />
                                    <div className="max-w-xs text-center md:text-right">
                                        <p className="text-slate-500 font-medium leading-relaxed">
                                            {trackingData.data.meaning}
                                        </p>
                                    </div>
                                </div>

                                {/* Modern Progress Tracker */}
                                <div className="relative pt-12">
                                    {/* Desktop Stepper */}
                                    <div className="hidden lg:flex justify-between relative">
                                        <div className="absolute top-[22px] left-0 right-0 h-[3px] bg-slate-50 -z-0" />
                                        <div 
                                            className="absolute top-[22px] left-0 h-[3px] bg-gradient-to-r from-primary to-accent transition-all duration-1000 ease-out" 
                                            style={{ width: `${((currentStep - 1) / (steps.length - 1)) * 100}%` }}
                                        />
                                        
                                        {steps.map((step, idx) => {
                                            const stepNum = idx + 1;
                                            const isCompleted = currentStep > stepNum;
                                            const isActive = currentStep === stepNum;

                                            return (
                                                <div key={idx} className="flex flex-col items-center relative z-10 w-24">
                                                    <div className={`w-12 h-12 rounded-full flex items-center justify-center border-4 transition-all duration-500 shadow-sm ${
                                                        isCompleted ? 'bg-primary border-primary text-white' : 
                                                        isActive ? 'bg-white border-accent text-accent scale-125 shadow-xl shadow-accent/20' : 
                                                        'bg-white border-slate-50 text-slate-300'
                                                    }`}>
                                                        {isCompleted ? <CheckCircle2 size={24} /> : (
                                                            <span className="text-sm font-black">{stepNum}</span>
                                                        )}
                                                    </div>
                                                    <div className="mt-4 text-center">
                                                        <div className={`text-[10px] font-black uppercase tracking-widest leading-tight ${isActive ? 'text-slate-900' : 'text-slate-400'}`}>
                                                            {step.label}
                                                        </div>
                                                        <div className="text-[8px] text-slate-300 font-bold mt-1 uppercase tracking-tighter hidden md:block">{step.desc}</div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>

                                    {/* Mobile/Tablet Vertical Stepper */}
                                    <div className="lg:hidden flex flex-col gap-10">
                                        {steps.map((step, idx) => {
                                            const stepNum = idx + 1;
                                            const isCompleted = currentStep > stepNum;
                                            const isActive = currentStep === stepNum;

                                            return (
                                                <div key={idx} className="flex items-start gap-6 group">
                                                    <div className="relative flex flex-col items-center">
                                                        <div className={`w-12 h-12 rounded-full flex items-center justify-center border-4 transition-all ${
                                                            isCompleted ? 'bg-primary border-primary text-white' : 
                                                            isActive ? 'bg-white border-accent text-accent scale-110 shadow-lg' : 
                                                            'bg-white border-slate-50 text-slate-200'
                                                        }`}>
                                                            {isCompleted ? <CheckCircle2 size={20} /> : <span className="text-sm font-black">{stepNum}</span>}
                                                        </div>
                                                        {idx !== steps.length - 1 && (
                                                            <div className={`w-[3px] h-10 mt-2 ${isCompleted ? 'bg-primary' : 'bg-slate-50'}`} />
                                                        )}
                                                    </div>
                                                    <div className="pt-1">
                                                        <div className={`text-sm font-black uppercase tracking-widest ${isActive ? 'text-slate-900' : 'text-slate-400'}`}>{step.label}</div>
                                                        <div className="text-xs text-slate-400 font-medium mt-1">{step.desc}</div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>

                                {/* Next Action Card */}
                                <div className="mt-16 p-8 rounded-[2rem] bg-slate-50/50 border border-slate-100 flex flex-col md:flex-row items-center gap-6">
                                    <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-primary shadow-sm shrink-0">
                                        <Clock size={32} />
                                    </div>
                                    <div className="text-center md:text-left flex-grow">
                                        <div className="text-[10px] font-black uppercase tracking-widest text-primary mb-1">Recommended Action</div>
                                        <h4 className="text-xl font-bold text-slate-900">{trackingData.data.next_step}</h4>
                                    </div>
                                    <a 
                                        href="#contact" 
                                        className="px-8 py-4 bg-white border border-slate-200 rounded-2xl font-black text-sm text-slate-600 hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-all shadow-sm"
                                    >
                                        Help Center
                                    </a>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Error State */}
                    {queryId && !isLoading && !trackingData?.success && (
                        <div className="bg-white rounded-[3rem] p-12 text-center shadow-2xl shadow-red-500/5 border border-red-50/50 animate-in zoom-in-95 duration-500">
                            <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-8">
                                <Search className="w-10 h-10 text-red-500" />
                            </div>
                            <h3 className="text-3xl font-display font-black text-slate-900 mb-4">Application Not Found</h3>
                            <p className="text-slate-500 text-lg max-w-md mx-auto mb-10 leading-relaxed">
                                We couldn't find any application matching <span className="text-slate-900 font-bold">"{queryId}"</span>. Please verify your Reference ID or Mobile Number and try again.
                            </p>
                            <button
                                onClick={() => { setSearchId(''); setQueryId(''); }}
                                className="bg-slate-900 text-white px-10 py-5 rounded-2xl font-black hover:bg-primary transition-all shadow-xl shadow-dark/20"
                            >
                                Try Search Again
                            </button>
                        </div>
                    )}

                    {/* Empty State / Guidelines */}
                    {!queryId && !isLoading && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-1000">
                            {[
                                { icon: <Search className="text-primary" />, title: 'Universal Search', text: 'Tracking works with Reference ID or your Registered Mobile Number.' },
                                { icon: <Clock className="text-accent" />, title: 'Real-time Flow', text: 'Updates are synchronized directly from our field operations team.' }
                            ].map((item, i) => (
                                <div key={i} className="bg-white/40 p-10 rounded-[2.5rem] border border-white shadow-sm hover:shadow-xl transition-all duration-500">
                                    <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                                        {item.icon}
                                    </div>
                                    <h4 className="text-xl font-display font-black text-slate-900 mb-3">{item.title}</h4>
                                    <p className="text-slate-500 font-medium leading-relaxed">{item.text}</p>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </main>

            <Footer />
        </div>
    );
}
